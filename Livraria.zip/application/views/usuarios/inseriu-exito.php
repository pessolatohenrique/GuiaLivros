<!DOCTYPE html>
<html>
<head>
	<title>Livraria | Usuario</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('css/bootstrap.css')?>">
</head>
<body>
	<div class="container">
		<h1>Registro inserido com sucesso!</h1>
	</div>
</body>
</html>